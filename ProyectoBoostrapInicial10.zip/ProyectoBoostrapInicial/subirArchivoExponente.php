<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regístrate</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="formatoRegistro.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<header style="background-color: #E3E3E3;">
    <div id="Flyer" class="container">
        <div class="d-flex flex-wrap justify-content-center gap">
            <div class="d-flex align-items-center" style="gap: 1rem;">
                <a href="https://www.unam.mx"><img src="./imagenes/Logo Unam.png" class="card-img-top" alt="Logo Unam" style="width: 15rem; margin-right: 15rem;"></a>
                <img src="./imagenes/logo.png" class="card-img-top" alt="Logo CIMCA" style="width: 6.5rem;">
                <a href="https://www.ingenieria.unam.mx"><img src="./imagenes/Logo FI.png" class="card-img-top" alt="Logo FI" style="width: 22rem; margin-left: 15rem;"></a>
            </div>
        </div>
    </div>
</header>

<body>
    <nav class="navbar navbar-expand-lg" style="border-top: 3px solid red; border-bottom: 3px solid red; background-color: white; position: sticky; top: 0; z-index: 1000;">
        <div class="container-fluid d-flex justify-content-center">
            <div class="d-flex gap-3">
                <a class="navbar-brand" href="index.php">Bienvenido</a>
                <a class="navbar-brand" href="objetivos.html">Objetivos</a>
                <a class="navbar-brand" href="ejesTematicos.html">Ejes Temáticos</a>
                <a class="navbar-brand" href="ComiteEvaluador.php">Comité Evaluador</a>
                <a class="navbar-brand" href="IniciarSesion.html">Iniciar Sesión</a>
                <a class="navbar-brand" href="miperfil.html">Mi perfil</a>
            </div>
        </div>
    </nav>

    <div class="text-center">
        <img id="ip_logo" src="./imagenes/logoCIMCA.jpg" style="max-height: 150px; width: 50%;">
    </div>

    <h1 class="center text-center" > Primero debes subir en este apartado el archivo de tu ponencia  </h1>

    <div class="container">
       <form action="registro_exponente.php" method="POST" enctype="multipart/form-data">
            <label for="archivo">Sube tu archivo (PDF):</label>
            <input type="file" name="archivo" accept=".pdf">
            <button type="submit" class="btn btn-primary">REGISTRARSE</button>
        </form>
    </div>

</body>
</html>
