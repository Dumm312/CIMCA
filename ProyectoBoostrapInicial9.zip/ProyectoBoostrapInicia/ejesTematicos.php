<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">  <!--Esto se agrega para usar el css de bootstrap-->
    <!-- <link rel="stylesheet" href="formatpage.css"> -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<!-- Encabezado de la página -->
<header style="background-color: #E3E3E3;">
    <div id="Flyer" class="container">
      <div class="d-flex flex-wrap justify-content-center gap">
        <div class="d-flex align-items-center" style="gap: 1rem;">
          <a href = "https://www.unam.mx"><img src="./imagenes/Logo Unam.png" class="card-img-top" alt="Logo Unam" style="width: 15rem; margin-right: 15rem;"></a>
          <img src="./imagenes/logo.png" class="card-img-top" alt="Logo CIMCA" style="width: 6.5rem;">
          <a href = "https://www.ingenieria.unam.mx"><img src="./imagenes/Logo FI.png" class="card-img-top" alt="Logo FI" style="width: 22rem; margin-left: 15rem;"></a>
        </div>
      </div>
    </div>
</header>

<body>
    <nav class="navbar navbar-expand-lg sticky-top" style="border-top: 3px solid red; border-bottom: 3px solid red; background-color: white; z-index: 1000;">
        <div class="container-fluid">
            <!-- Botón toggler para móviles -->
            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Contenido colapsable -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav w-100 justify-content-center gap-lg-3">
                    <?php if (isset($_SESSION['correo'])): ?>
                        <a class="nav-link" href="index.php">Bienvenido</a>
                        <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                        <a class="nav-link" href="miperfil.php">Mi perfil</a>
                    <?php else: ?>
                        <a class="nav-link" href="index.php">Bienvenido</a>
                        <a class="nav-link" href="objetivos.php">Objetivos</a>
                        <a class="nav-link" href="ejesTematicos.php">Ejes Temáticos</a>
                        <a class="nav-link" href="ComiteEvaluador.php">Comité Evaluador</a>
                        <a class="nav-link" href="IniciarSesion.php">Iniciar Sesión</a>
                        <br><br>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Logo principal de CIMCA -->
    <div class="text-center">
       <img id="ip_logo" src="./imagenes/logoCIMCA.jpg" style="max-height: 150px; width: 50%;">
    </div>


    <br>
    <?php
    // 1. Conexión a la base de datos
    include "Modelo/conexion.php";

    // 2. Obtener los ejes temáticos (Agua, Aire, Suelo, etc.)
    $sql_ejes = "SELECT id_Eje, tema, logo_Eje FROM EJES WHERE id_Congreso = ?";
    $stmt_ejes = $conn->prepare($sql_ejes);
    $id_congreso = $_GET['id_congreso'] ?? 1; // Puedes obtenerlo de URL, sesión, etc.
    $stmt_ejes->bind_param("i", $id_congreso);
    $stmt_ejes->execute();
    $result_ejes = $stmt_ejes->get_result();

    if ($result_ejes->num_rows > 0) {
        $ejes = $result_ejes->fetch_all(MYSQLI_ASSOC);
        
        // Dividir los ejes en dos grupos para mostrar en dos filas
        $mitad = ceil(count($ejes) / 2);
        $grupos = array_chunk($ejes, $mitad);
        
        // 3. Generar HTML para cada grupo
        foreach ($grupos as $grupo) {
            echo '<div class="container text-center">';
            
            foreach ($grupo as $eje) {
                $id_eje = $eje['id_Eje'];
                $tema = htmlspecialchars($eje['tema']);
                $logo = htmlspecialchars($eje['logo_Eje']);
                $modal_id = strtolower(str_replace(' ', '', $tema)) . 'Modal';
                ?>
                
                <!-- Elemento del eje -->
                <div class="d-inline-block m-4 text-center">
                    <div class="fw-bold mb-2 text-uppercase"><?= $tema ?></div>
                    <div class="rounded-circle overflow-hidden" style="width: 200px; height: 200px;">
                        <img src="<?= $logo ?>" 
                            class="element-icon w-100 h-100 object-fit-cover" 
                            alt="<?= $tema ?>"
                            data-bs-toggle="modal" 
                            data-bs-target="#<?= $modal_id ?>">
                    </div>
                </div>
                <?php
            }
            
            echo '</div>';
        }
        
        // 4. Generar los modales para cada eje
        foreach ($ejes as $eje) {
            $id_eje = $eje['id_Eje'];
            $tema = htmlspecialchars($eje['tema']);
            $logo = htmlspecialchars($eje['logo_Eje']);
            $modal_id = strtolower(str_replace(' ', '', $tema)) . 'Modal';
            ?>
            
            <!-- Modal para cada eje -->
            <div class="modal fade" id="<?= $modal_id ?>" tabindex="-1" aria-labelledby="<?= $modal_id ?>Label" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="<?= $modal_id ?>Label"><?= strtoupper($tema) ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body text-center">
                            <img src="<?= $logo ?>" alt="<?= $tema ?>" style="max-height: 200px;" class="mb-3">
                            
                            <!-- Subtemas del eje -->
                            <div class="text-start">
                                <?php
                                // Obtener subtemas para este eje
                                $sql_subtemas = "SELECT subtema FROM Subtema WHERE id_Eje = ?";
                                $stmt_subtemas = $conn->prepare($sql_subtemas);
                                $stmt_subtemas->bind_param("i", $id_eje);
                                $stmt_subtemas->execute();
                                $result_subtemas = $stmt_subtemas->get_result();
                                
                                if ($result_subtemas->num_rows > 0) {
                                    $contador = 1;
                                    while ($subtema = $result_subtemas->fetch_assoc()) {
                                        echo $contador . '. ' . htmlspecialchars($subtema['subtema']) . '<br>';
                                        $contador++;
                                    }
                                } else {
                                    echo "<p>No hay subtemas registrados para este eje.</p>";
                                }
                                $stmt_subtemas->close();
                                ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        echo "<p class='text-center'>No hay ejes temáticos registrados para este congreso.</p>";
    }

    $stmt_ejes->close();
    $conn->close();
    ?>
    <br>
    <br>
    <br>
    <br>




      <!-- Footer -->
      <footer id="footer">

        <div class="container">
            <!-- Footer Widgets
            ============================================= -->
            <div id="fondo" class="footer-widgets-container d-flex flex-wrap justify-content-between align-items-start">
                <!-- Primer bloque -->
                <div class="footer-widgets-wrap">
                    <div class="col_two_third">
                        <div class="widget clearfix">
                            <div class="col_one_third">
                                <img src="./imagenes/Letras FI.png" alt="" class="footer-logo" style="max-height: 100px; ">
                                <br>
                                <img src="./imagenes/logoDICyG.png" alt="" class="footer-logo" style="max-height: 90px; margin-left:30px">
                                <br><br>
                                <p><a href="paginas/aviso_privacidad.php" style="margin-left:5px"><strong>Aviso de Privacidad</strong></a></p>
                            </div>  
                        </div>
                    </div>
                </div>
            
                <!-- Segundo bloque -->
                <div class="footer-widgets-wrap">
                    <div class="col_two_third col_last">
                        <address class="nobottommargin" style="color: white;">
                            <a href="http://www.unam.mx" target="_blank"><strong>Universidad Nacional Autónoma de México</strong></a><br>
                            Facultad de Ingeniería, Av. Universidad 3000, Ciudad Universitaria, Coyoacán, Cd. Mx., CP 04510<br>
                        </address>
                        <strong style="color: white;">Teléfono: 55</strong> <br>
                        <strong style="color: white;">eMail: <a href="mailto:lagvillanueva@unam.mx">lagvillanueva@unam.mx</a></strong> <br><br>
                        <a href="https://www.facebook.com/FacultadIngenieriaUNAM" target="_blank"><i class="fa-brands fa-facebook fa-2x" style="color: white;"></i></a>
                        <a href="http://www.twitter.com/FIUNAM_MX" target="_blank"><i class="fa-brands fa-twitter fa-2x" style="color: white;"></i></a>
                        <a href="http://www.instagram.com/fiunam_mx/" target="_blank"><i class="fa-brands fa-instagram fa-2x" style="color: white;"></i></a>
                        <a href="http://www.youtube.com/user/TVIngenieria" target="_blank"><i class="fa-brands fa-youtube fa-2x" style="color: white;"></i></a>
                    </div>
                </div>
            
                <!-- Tercer bloque -->
                <div class="footer-widgets-wrap">
                    <div class="col_one_third col_last">
                        <div class="widget clearfix">
                            <h4 style="color: white;">Sitios de interés</h4>
                            <div class="widget_links">
                                <ul>
                                    <li><a href="https://www.ingenieria.unam.mx/" target="_blank">Facultad de Ingeniería</a></li>
                                    <li><a href="http://dicyg.fi-c.unam.mx:8080/Site" target="_blank">División de Ingeniería Civil y Geomática</a></li>
                                    <li><a href="https://www.ingenieria.unam.mx/deptohidraulica/" target="_blank">Hidráulica</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
        <!-- Copyrights-->
        <div id="copyrights2">
            <div class="container clearfix">
                <div class="nobottommargin">
                    <div class="copyrights2">
                        Todos los derechos reservados &copy; @2025
                        <!-- <a href="https://www.ingenieria.unam.mx">Facultad de Ingeniería</a>/<a href="https://www.unam.mx">UNAM</a>/ -->
                    </div>
                    <div class="copyrights3">
                        <p>Esta es la página electrónica de CIMCA - Congreso Internacional para el Manejo de la Contaminación Ambiental.</p>
                    </div>
                    <div>
                        <p class="copyrights3">Última actualización 24-03-2025</p>
                    </div>
                </div>  
            </div>
        </div><!-- #copyrights end -->
    </footer><!-- #footer end -->
  
  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <style>
      .element-icon {
          cursor: pointer;
          transition: transform 0.3s, filter 0.3s;
      }
      .element-icon:hover {
          transform: scale(1.05);
          filter: brightness(1.1);
      }
      .container {
          padding: 20px;
      }
      /* Efecto de sombra para los círculos */
      .rounded-circle {
          box-shadow: 0 4px 8px rgba(0,0,0,0.2);
          border: 3px solid white;
      }


      /* Style del footer */
      #footer {
        position: relative;
        background-color: #333333;
        border-top: 5px solid rgba(0,0,0,0.2);
    }

    #footer .footer-widgets-wrap {
        position: relative;
        padding-top:20px;
        padding-bottom: 0px;
    }

    .footer-widgets-wrap .col_full,
    .footer-widgets-wrap .col_half,
    .footer-widgets-wrap .col_one_third,
    .footer-widgets-wrap .col_two_third,
    .footer-widgets-wrap .col_three_fourth,
    .footer-widgets-wrap .col_one_fourth,
    .footer-widgets-wrap .col_one_fifth,
    .footer-widgets-wrap .col_two_fifth,
    .footer-widgets-wrap .col_three_fifth,
    .footer-widgets-wrap .col_four_fifth,
    .footer-widgets-wrap .col_one_sixth,
    .footer-widgets-wrap .col_five_sixth { margin-bottom: 0; }

    .btn-contacto {
    -webkit-border-radius: 7;
    -moz-border-radius: 7;
    border-radius: 7px;
    color: #ffffff;
    font-size: 14px;
    background: #cd171e;
    padding: 4px 10px 4px 10px;
    text-decoration: none;
    }

    .btn-contacto:hover {
    background: #d8d8d8;
    text-decoration: none;
    }

    .btn-local {
        margin-top:3px;
        color: #242323;
        background-color: #d43f3a;
        border-color: #17cdbe;
        font-size: 12px;
    }

    .btn-local:hover,
    .btn-local:focus,
    .btn-local.focus,
    .btn-local:active,
    .btn-local.active,
    .open > .dropdown-toggle.btn-local {
    color: #ffffff;
    background-color: #d8d8d8;
    border-color: #b0b0b0;
    }

    .btn-foraneo {
        margin-top:3px;
        color: #ffffff;
        background-color: #1a3d6c;
        border-color: #2b5d9f;
    }
   
    .btn-foraneo2 {
        margin-top:3px;
        background-color: #1a3d6c;
        color: #ffffff;
        font-size: 12px;
        border-color: #2b5d9f;
    }

    .btn-foraneo2:hover,
    .btn-foraneo2:focus,
    .btn-foraneo2.focus,
    .btn-foraneo2:active,
    .btn-local.active,
    .open > .dropdown-toggle.btn-foraneo {
        background-color: #e9ae3c;
        color: #ffffff;
        font-size: 12px;
        border-color: #c38a1d;
    }

    #copyrights {
        padding: 10px 0;
        background-color: #cd171e;
        font-size: 14px;
        line-height: 1.8;
    }

    #copyrights2 {
        padding: 5px 0;
        background-color: #CD171E;
        font-size: 14px;
        line-height: 1.8;
        color: #fff;
    }

    .copyrights2 a{
        display: inline-block;
        margin: 0 3px;
        color: #fff;
    }

    .copyrights2 a:hover {
        display: inline-block;
        margin: 0 3px;
        color:#ffffff;
    }

    li{
        color: rgb(255, 255, 255);
    }


    /* Esto es para transformar en mayúsculas nuestros temas de ejes temáticos */
    .text-uppercase {
        text-transform: uppercase;
    }
    
  </style>
</body>
</html>