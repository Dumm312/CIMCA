<?php
// header('Content-Type: application/json');

// // Conexión a la base de datos
$host = "localhost";
$user = "root";  // Cambia esto si usas otro usuario
$password = "";  // Cambia esto si tienes una contraseña
$dbname = "cimca";
$conn = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die(json_encode(["error" => "Error en la conexión: " . $conn->connect_error]));
}

$conn->set_charset("utf8");
// // Obtener las imagenes
// $sql = "SELECT * FROM patrocinador";
// $result = $conn->query($sql);

// $imagenes = [];
// while ($row = $result->fetch_assoc()) {

// }


// $conn->close();


?>
