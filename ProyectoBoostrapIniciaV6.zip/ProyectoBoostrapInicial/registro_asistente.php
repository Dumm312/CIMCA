<?php
session_start();
// if (isset($_SESSION['usuario_id'])) {
//     header("Location: registro_asistente.php");
//     exit;
// }

include("Modelo/conexion.php"); // Asegúrate que esta conexión funciona

$correo = $_SESSION['correo'];

// Buscar id_Usuario basado en el correo
$sql = "SELECT id_Usuario FROM USUARIO WHERE correo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $id_usuario = $row['id_Usuario'];

    // Suponiendo que tienes un congreso activo con id = 1 (puedes hacerlo dinámico si deseas)
    $id_congreso = 1;

    // Registrar en la tabla EVENTO como asistente
    $sql_insert = "INSERT INTO EVENTO (id_Usuario, id_Congreso, asistente, cartel, ponencia) 
                   VALUES (?, ?, 1, 0, 0)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("ii", $id_usuario, $id_congreso);

    if ($stmt_insert->execute()) {
        echo "<script>alert('Registro como asistente exitoso'); window.location.href = 'index.php';</script>";
    } else {
        echo "Error al registrar: " . $conn->error;
    }
} else {
    echo "Usuario no encontrado.";
}
?>
