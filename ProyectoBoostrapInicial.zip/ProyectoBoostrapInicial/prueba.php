<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Objetivos</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* Estilos adicionales para el acordeón */
        .sub-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            background-color: #f8f9fa;
        }
        .sub-item img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
            margin-right: 15px;
        }
        .sub-item-info {
            flex: 1;
        }
        .accordion-button:not(.collapsed) {
            background-color: #f8f9fa;
            color: #dc3545;
        }
        .accordion-button:focus {
            box-shadow: none;
            border-color: rgba(0,0,0,.125);
        }
    </style>
</head>

<!-- Encabezado de la página -->
<header style="background-color: #E3E3E3;">
    <div id="Flyer" class="container">
      <div class="d-flex flex-wrap justify-content-center gap">
        <div class="d-flex align-items-center" style="gap: 1rem;">
          <a href = "https://www.unam.mx"><img src="./Carrusel-Imagenes/Logo Unam.png" class="card-img-top" alt="Logo Unam" style="width: 15rem; margin-right: 15rem;"></a>
          <img src="./Carrusel-Imagenes/logo.png" class="card-img-top" alt="Logo CIMCA" style="width: 6.5rem;">
          <a href = "https://www.ingenieria.unam.mx"><img src="./Carrusel-Imagenes/Logo FI.png" class="card-img-top" alt="Logo FI" style="width: 22rem; margin-left: 15rem;"></a>
        </div>
      </div>
    </div>
</header>

<body>
    <nav class="navbar navbar-expand-lg" style="border-top: 3px solid red; border-bottom: 3px solid red; background-color: white; position: sticky; top: 0; z-index: 1000;">
        <div class="container-fluid d-flex justify-content-center">
            <div class="d-flex gap-3">
                <a class="navbar-brand" href="index.html">Bienvenido</a>
                <a class="navbar-brand" href="objetivos.html">Objetivos</a>
                <a class="navbar-brand" href="ejesTematicos.html">Ejes Temáticos</a>
                <a class="navbar-brand" href="ComiteEvaluador.html">Comité Evaluador</a>
                <a class="navbar-brand" href="IniciarSesion.html">Iniciar Sesión</a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>

    <!-- Logo principal de CIMCA -->
    <div class="text-center">
        <img id="ip_logo" src="./Carrusel-Imagenes/logoCIMCA.jpg" style="max-height: 150px; width: 50%;">
    </div>

    <!-- Sección principal con el acordeón dinámico -->
    <div class="container my-5">
        <?php
        /**
         * Generador automático de acordeón HTML desde base de datos
         */
        function escapeHtml($text) {
            return htmlspecialchars($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        try {
            // Configuración de la conexión (ajusta estos valores)
            $dbHost = 'localhost';
            $dbName = 'rentapeliculas';
            $dbUser = 'root';
            $dbPass = '';
            
            $db = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8", $dbUser, $dbPass);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Consulta para elementos principales
            $queryPrincipales = "SELECT * FROM elementos 
                                WHERE tipo = 'elemento' 
                                ORDER BY orden ASC";
            $stmtPrincipales = $db->query($queryPrincipales);
            $elementosPrincipales = $stmtPrincipales->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($elementosPrincipales) > 0) {
                echo '<div class="accordion" id="elementsAccordion">';
                
                foreach ($elementosPrincipales as $elemento) {
                    // Consulta para subelementos
                    $querySubelementos = "SELECT * FROM elementos 
                                        WHERE tipo = 'subelemento' AND elemento_padre_id = :padre_id
                                        ORDER BY orden ASC";
                    $stmtSub = $db->prepare($querySubelementos);
                    $stmtSub->execute([':padre_id' => $elemento['id']]);
                    $subelementos = $stmtSub->fetchAll(PDO::FETCH_ASSOC);
                    
                    $collapseId = 'collapse_' . $elemento['id'];
                    
                    echo '
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold" type="button" 
                                data-bs-toggle="collapse" data-bs-target="#'.$collapseId.'"
                                aria-expanded="false" aria-controls="'.$collapseId.'">
                                '.escapeHtml($elemento['nombre']).'
                            </button>
                        </h2>
                        <div id="'.$collapseId.'" class="accordion-collapse collapse" 
                            data-bs-parent="#elementsAccordion">
                            <div class="accordion-body">';
                    
                    if (count($subelementos) > 0) {
                        foreach ($subelementos as $subelemento) {
                            $imagen = !empty($subelemento['imagen']) 
                                    ? escapeHtml($subelemento['imagen'])
                                    : './Carrusel-Imagenes/default.avif';
                            
                            echo '
                            <div class="sub-item">
                                <img src="'.$imagen.'" 
                                    alt="'.escapeHtml($subelemento['nombre']).'" 
                                    class="img-fluid">
                                <div class="sub-item-info">
                                    <h3>'.escapeHtml($subelemento['nombre']).'</h3>
                                    <p class="mb-0">'.escapeHtml($subelemento['descripcion']).'</p>
                                </div>
                            </div>';
                        }
                    } else {
                        echo '<p class="text-muted">No hay subelementos disponibles.</p>';
                    }
                    
                    echo '
                            </div>
                        </div>
                    </div>';
                }
                
                echo '</div>'; // Cierre del accordion
            } else {
                echo '<div class="alert alert-info">No hay elementos para mostrar.</div>';
            }
            
        } catch (PDOException $e) {
            echo '<div class="alert alert-danger">Error al cargar los datos: '.escapeHtml($e->getMessage()).'</div>';
        }
        ?>
    </div>

    <!-- Footer -->
    <footer id="footer">
    <div class="container">
        <!-- Footer Widgets
        ============================================= -->
        <div id="fondo" class="footer-widgets-container d-flex flex-wrap justify-content-between align-items-start">
            <!-- Primer bloque -->
            <div class="footer-widgets-wrap">
                <div class="col_two_third">
                    <div class="widget clearfix">
                        <div class="col_one_third">
                            <img src="./Carrusel-Imagenes/Letras FI.png" alt="" class="footer-logo" style="max-height: 100px; ">
                            <br>
                            <img src="./Carrusel-Imagenes/logoDICyG.png" alt="" class="footer-logo" style="max-height: 90px; margin-left:30px">
                            <br><br>
                            <!-- <p><a href="nuestra_facultad/contacto.php" class="btn btn-local" style="margin-left:35px">Contacto</a></p> -->
                            <p><a href="paginas/aviso_privacidad.php" style="margin-left: 0px;"><strong>Aviso de Privacidad</strong></a></p>
                        </div>  
                    </div>
                </div>
            </div>
            
            <!-- Segundo bloque -->
            <div class="footer-widgets-wrap">
                <div class="col_two_third col_last">
                    <address class="nobottommargin" style="color: white;">
                        <a href="http://www.unam.mx" target="_blank"><strong>Universidad Nacional Autónoma de México</strong></a><br>
                        Facultad de Ingeniería, Av. Universidad 3000, Ciudad Universitaria, Coyoacán, Cd. Mx., CP 04510<br>
                    </address>
                    <strong style="color: white;">Teléfono: 55</strong> <br>
                    <strong style="color: white;">eMail: <a href="mailto:lagvillanueva@unam.mx">lagvillanueva@unam.mx</a></strong> <br><br>
                    <a href="https://www.facebook.com/FacultadIngenieriaUNAM" target="_blank"><i class="fa-brands fa-facebook fa-2x" style="color: white;"></i></a>
                    <a href="http://www.twitter.com/FIUNAM_MX" target="_blank"><i class="fa-brands fa-twitter fa-2x" style="color: white;"></i></a>
                    <a href="http://www.instagram.com/fiunam_mx/" target="_blank"><i class="fa-brands fa-instagram fa-2x" style="color: white;"></i></a>
                    <a href="http://www.youtube.com/user/TVIngenieria" target="_blank"><i class="fa-brands fa-youtube fa-2x" style="color: white;"></i></a>
                </div>
            </div>
            
            <!-- Tercer bloque -->
            <div class="footer-widgets-wrap">
                <div class="col_one_third col_last">
                    <div class="widget clearfix">
                        <h4 style="color: white;">Sitios de interés</h4>
                        <div class="widget_links">
                            <ul>
                                <li><a href="https://www.ingenieria.unam.mx/" target="_blank">Facultad de Ingeniería</a></li>
                            <li><a href="http://dicyg.fi-c.unam.mx:8080/Site" target="_blank">División de Ingeniería Civil y Geomática</a></li>
                            <li><a href="https://www.ingenieria.unam.mx/deptohidraulica/" target="_blank">Hidráulica</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
            
        <!-- Copyrights-->
        <div id="copyrights2">
            <div class="container clearfix">
                <div class="nobottommargin">
                    <div class="copyrights2">
                        Todos los derechos reservados &copy; @2025
                        <!-- <a href="https://www.ingenieria.unam.mx">Facultad de Ingeniería</a>/<a href="https://www.unam.mx">UNAM</a>/ -->
                    </div>
                    <div class="copyrights3">
                        <p>Esta es la página electrónica de CIMCA - Congreso Internacional para el Manejo de la Contaminación Ambiental.</p>
                    </div>
                    <div>
                        <p class="copyrights3">Última actualización 24-03-2025</p>
                    </div>
                </div>  
        </div>
    </div><!-- #copyrights end -->
    </footer><!-- #footer end -->

    <script src="./js/bootstrap.bundle.min.js"></script> <!--Esto se usa para llamar a la carpeta de js de bootstrap-->  
  
</body>
</html>