<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenidos</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">  <!--Esto se agrega para usar el css de bootstrap-->
    <!-- <link rel="stylesheet" href="formatpage.css"> -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<!-- Encabezado de la página -->
<header style="background-color: #E3E3E3;">
    <div id="Flyer" class="container">
      <div class="d-flex flex-wrap justify-content-center gap">
        <div class="d-flex align-items-center" style="gap: 1rem;">
          <a href = "https://www.unam.mx"><img src="./Carrusel-Imagenes/Logo Unam.png" class="card-img-top" alt="Logo Unam" style="width: 15rem; margin-right: 15rem;"></a>
          <img src="./Carrusel-Imagenes/logo.png" class="card-img-top" alt="Logo CIMCA" style="width: 6.5rem;">
          <a href = "https://www.ingenieria.unam.mx"><img src="./Carrusel-Imagenes/Logo FI.png" class="card-img-top" alt="Logo FI" style="width: 22rem; margin-left: 15rem;"></a>
        </div>
      </div>
    </div>
</header>

<body>
    <nav class="navbar navbar-expand-lg sticky-top" style="border-top: 3px solid red; border-bottom: 3px solid red; background-color: white; z-index: 1000;">
        <div class="container-fluid">
            <!-- Botón toggler para móviles -->
            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Contenido colapsable -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav w-100 justify-content-center gap-lg-3">
                    <a class="nav-link" href="index.php">Bienvenido</a>
                    <a class="nav-link" href="objetivos.html">Objetivos</a>
                    <a class="nav-link" href="ejesTematicos.html">Ejes Temáticos</a>
                    <a class="nav-link" href="ComiteEvaluador.php">Comité Evaluador</a>
                    <a class="nav-link" href="IniciarSesion.html">Iniciar Sesión</a>
                    
                    <!-- Esto a continuación solo deberá aparecer cuando se tenga una sesión activa -->
                    <a class="nav-link" href="miperfil.html">Mi perfil</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Logo principal de CIMCA -->
    <div class="text-center">
       <img id="ip_logo" src="./Carrusel-Imagenes/logoCIMCA.jpg" style="max-height: 150px; width: 50%;">
    </div>

    <br>
    <br>
    <div>
        <p class="text-capitalize; fs-2 fw-bold  center text-center">"Congreso Internacional para el Manejo de la Contaminación Ambiental"</p>
        <p class="text-capitalize; fs-3  center text-center">3ra Edición</p>
        <?php
            include "Modelo/conexion.php";

            // Obtener el id_Congreso (ej: desde URL, sesión, o valor fijo)
            $id_congreso = $_GET['id_congreso'] ?? 1; // Valor por defecto: 1

            // Consulta filtrada por id_Congreso para el carrusel
            $sql = "SELECT edicion FROM congreso WHERE id_Congreso = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id_congreso);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $first = true;
                while ($row = $result->fetch_assoc()) {
                    $edicion = htmlspecialchars($row["nombre_Pat"]);
                    ?>
  
                    <?php
                    $first = false;
                }
            } else {
                echo "<p>No hay patrocinadores para este congreso.</p>";
            }
            $stmt->close();
            $conn->close();
            ?>
        
    </div>
    <br>
    <!-- Sección del Flyer -->
    <div id="Flyer" class="container">
        <div class="d-flex flex-wrap justify-content-center gap-3">
            <div class="card" style="width: 18rem;">
                <div class="img-container">
                    <img src="./Carrusel-Imagenes/flyer.jpg" class="card-img-top zoomable-img" alt="Flyer de CIMCA">
                    <div class="zoom-icon" onclick="openFullscreen(this)">
                        🔍
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal Agrandar Flye -->
    <div id="fullscreen-modal" class="fullscreen-modal">
        <span class="close-btn" onclick="closeFullscreen()">&times;</span>
        <img class="fullscreen-img" id="fullscreen-img">
    </div>
    
    <br>
    <br>

    <!-- Sección de Registro -->
    <div class="container">
        <div class="d-flex flex-wrap justify-content-center gap-3">
            <div class="card" style="width: 18rem;">
                <img src="./Carrusel-Imagenes/asistente.jpg" class="card-img-top" alt="Imagen Asistente">
                <div class="card-body">
                    <h5 class="card-title">Asistente</h5>
                    <p class="card-text">En esta sección podrás registrate como "Estudiante", "Investigador", "Docente", "Empresa" entre otros, para que puedas asistir al ciclo.</p>
                    <a class="btn btn-primary">REGISTRARSE </a>
                        <!-- echo "<script>alert('Seguro que quieres registrarte como ASISENTE?.');window.location.href = 'http://localhost/';</script>"; -->
                    <br><br><br>
                    <i class="material-icons right icon-large" style="color: blue;">assignment</i>
                </div>
            </div>
      
            <div class="card" style="width: 18rem;">
                <img src="./Carrusel-Imagenes/participante.jpg" class="card-img-top" alt="Imagen Participante">
                <div class="card-body">
                    <h5 class="card-title">Participante</h5>
                    <p class="card-text">En esta sección podrás registrate como "PARTICIPANTE".</p>
                    <a  class="btn btn-primary">REGISTRARSE (Cartel)</a>
                    <!-- echo "<script>alert('Seguro que quieres registrarte?.');window.location.href = 'http://localhost/';</script>"; -->
                    <br><br>
                    <a  class="btn btn-primary">REGISTRARSE (Exponente)</a>
                    <!-- echo "<script>alert('Seguro que quieres registrarte como exponente?.');window.location.href = 'http://localhost/';</script>"; -->
                    <br><br><br>
                    <i class="material-icons right icon-large" style="color: blue;">collections</i>
                </div>
            </div>

            <div class="card" style="width: 18rem;">
                <img src="./Carrusel-Imagenes/lineamientos.jpg" class="card-img-top" alt="Imagen Lineamientos">
                <div class="card-body">
                    <h5 class="card-title">Lineamientos</h5>
                    <p class="card-text">En esta sección podrás consultar los lineamientos, requisitos y procedimientos.</p>
                    <a  class="btn btn-primary">LINEAMIENTOS</a>
                    <br><br>
                    <a  class="btn btn-primary">PLANTILLA</a>
                    <br><br>
                    <i class="material-icons right icon-large" style="color: blue;">collections_bookmark</i>
                </div>
            </div>
        </div>
    </div>
     
    <br>
    <br>
    <br>
    
    <!-- Sección que contiene lo que vamos a mostrar en nuestro carrusel de imagenes, que en este caso son los aptrocinadores -->    
    <div id="carouselExampleRide" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php
            include "Modelo/conexion.php";

            // Obtener el id_Congreso (ej: desde URL, sesión, o valor fijo)
            $id_congreso = $_GET['id_congreso'] ?? 1; // Valor por defecto: 1

            // Consulta filtrada por id_Congreso para el carrusel
            $sql = "SELECT nombre_Pat, imagen FROM PATROCINADOR WHERE id_Congreso = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id_congreso);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $first = true;
                while ($row = $result->fetch_assoc()) {
                    $nombre = htmlspecialchars($row["nombre_Pat"]);
                    $ruta_imagen = htmlspecialchars($row["imagen"]); // Ruta completa desde la BD
                    ?>
                    <!--Interval aumenta o reduce el tiempo de desplazamiento  -->
                    <div class="carousel-item <?php echo $first ? 'active' : ''; ?>" data-bs-interval="2000">
                        <img src="<?php echo $ruta_imagen; ?>" 
                            class="d-block mx-auto w-10" 
                            style="max-height: 300px; object-fit: cover;" 
                            alt="Logo de <?php echo $nombre; ?>">
                    </div>
                    <?php
                    $first = false;
                }
            } else {
                echo "<p>No hay patrocinadores para este congreso.</p>";
            }
            $stmt->close();
            $conn->close();
            ?>
        </div>
        <!-- Botones de navegación del carrusel -->
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleRide" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleRide" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <br><br><br>

    <!-- Imagen de gota de agua -->
    <img src="./Carrusel-Imagenes/Fondo.jpg" class="img-fluid"  alt="Imagen que muestra fondo" style="max-height: 400px; width: 100%; object-fit: cover;">

    <!-- Footer de la página  -->
    <!-- Footer
    ============================================= -->
    <footer id="footer">

        <div class="container">
            <!-- Footer Widgets
            ============================================= -->
            <div id="fondo" class="footer-widgets-container d-flex flex-wrap justify-content-between align-items-start">
                <!-- Primer bloque -->
                <div class="footer-widgets-wrap">
                    <div class="col_two_third">
                        <div class="widget clearfix">
                            <div class="col_one_third">
                                <img src="./Carrusel-Imagenes/Letras FI.png" alt="" class="footer-logo" style="max-height: 100px; ">
                                <br>
                                <img src="./Carrusel-Imagenes/logoDICyG.png" alt="" class="footer-logo" style="max-height: 90px; margin-left:30px">
                                <br><br>
                                <p><a href="paginas/aviso_privacidad.php" style="margin-left:5px"><strong>Aviso de Privacidad</strong></a></p>
                            </div>  
                        </div>
                    </div>
                </div>
            
                <!-- Segundo bloque -->
                <div class="footer-widgets-wrap">
                    <div class="col_two_third col_last">
                        <address class="nobottommargin" style="color: white;">
                            <a href="http://www.unam.mx" target="_blank"><strong>Universidad Nacional Autónoma de México</strong></a><br>
                            Facultad de Ingeniería, Av. Universidad 3000, Ciudad Universitaria, Coyoacán, Cd. Mx., CP 04510<br>
                        </address>
                        <strong style="color: white;">Teléfono: 55</strong> <br>
                        <strong style="color: white;">eMail: <a href="mailto:lagvillanueva@unam.mx">lagvillanueva@unam.mx</a></strong> <br><br>
                        <a href="https://www.facebook.com/FacultadIngenieriaUNAM" target="_blank"><i class="fa-brands fa-facebook fa-2x" style="color: white;"></i></a>
                        <a href="http://www.twitter.com/FIUNAM_MX" target="_blank"><i class="fa-brands fa-twitter fa-2x" style="color: white;"></i></a>
                        <a href="http://www.instagram.com/fiunam_mx/" target="_blank"><i class="fa-brands fa-instagram fa-2x" style="color: white;"></i></a>
                        <a href="http://www.youtube.com/user/TVIngenieria" target="_blank"><i class="fa-brands fa-youtube fa-2x" style="color: white;"></i></a>
                    </div>
                </div>
            
                <!-- Tercer bloque -->
                <div class="footer-widgets-wrap">
                    <div class="col_one_third col_last">
                        <div class="widget clearfix">
                            <h4 style="color: white;">Sitios de interés</h4>
                            <div class="widget_links">
                                <ul>
                                    <li><a href="https://www.ingenieria.unam.mx/" target="_blank">Facultad de Ingeniería</a></li>
                                    <li><a href="http://dicyg.fi-c.unam.mx:8080/Site" target="_blank">División de Ingeniería Civil y Geomática</a></li>
                                    <li><a href="https://www.ingenieria.unam.mx/deptohidraulica/" target="_blank">Hidráulica</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
        <!-- Copyrights-->
        <div id="copyrights2">
            <div class="container clearfix">
                <div class="nobottommargin">
                    <div class="copyrights2">
                        Todos los derechos reservados &copy; @2025
                        <!-- <a href="https://www.ingenieria.unam.mx">Facultad de Ingeniería</a>/<a href="https://www.unam.mx">UNAM</a>/ -->
                    </div>
                    <div class="copyrights3">
                        <p>Esta es la página electrónica de CIMCA - Congreso Internacional para el Manejo de la Contaminación Ambiental.</p>
                    </div>
                    <div>
                        <p class="copyrights3">Última actualización 24-03-2025</p>
                    </div>
                </div>  
            </div>
        </div><!-- #copyrights end -->
    </footer><!-- #footer end -->

    <style>
        #footer {
            position: relative;
            background-color: #333333;
            border-top: 5px solid rgba(0,0,0,0.2);
        }

        #footer .footer-widgets-wrap {
            position: relative;
            padding-top:20px;
            padding-bottom: 0px;
        }

        .footer-widgets-wrap .col_full,
        .footer-widgets-wrap .col_half,
        .footer-widgets-wrap .col_one_third,
        .footer-widgets-wrap .col_two_third,
        .footer-widgets-wrap .col_three_fourth,
        .footer-widgets-wrap .col_one_fourth,
        .footer-widgets-wrap .col_one_fifth,
        .footer-widgets-wrap .col_two_fifth,
        .footer-widgets-wrap .col_three_fifth,
        .footer-widgets-wrap .col_four_fifth,
        .footer-widgets-wrap .col_one_sixth,
        .footer-widgets-wrap .col_five_sixth { margin-bottom: 0; }

        .btn-contacto {
        -webkit-border-radius: 7;
        -moz-border-radius: 7;
        border-radius: 7px;
        color: #ffffff;
        font-size: 14px;
        background: #cd171e;
        padding: 4px 10px 4px 10px;
        text-decoration: none;
        }

        .btn-contacto:hover {
        background: #d8d8d8;
        text-decoration: none;
        }

        .btn-local {
            margin-top:3px;
            color: #242323;
            background-color: #d43f3a;
            border-color: #17cdbe;
            font-size: 12px;
        }

        .btn-local:hover,
        .btn-local:focus,
        .btn-local.focus,
        .btn-local:active,
        .btn-local.active,
        .open > .dropdown-toggle.btn-local {
        color: #ffffff;
        background-color: #d8d8d8;
        border-color: #b0b0b0;
        }

        .btn-foraneo {
            margin-top:3px;
            color: #ffffff;
            background-color: #1a3d6c;
            border-color: #2b5d9f;
        }
       
        .btn-foraneo2 {
            margin-top:3px;
            background-color: #1a3d6c;
            color: #ffffff;
            font-size: 12px;
            border-color: #2b5d9f;
        }

        .btn-foraneo2:hover,
        .btn-foraneo2:focus,
        .btn-foraneo2.focus,
        .btn-foraneo2:active,
        .btn-local.active,
        .open > .dropdown-toggle.btn-foraneo {
            background-color: #e9ae3c;
            color: #ffffff;
            font-size: 12px;
            border-color: #c38a1d;
        }

        #copyrights {
            padding: 10px 0;
            background-color: #cd171e;
            font-size: 14px;
            line-height: 1.8;
        }

        #copyrights2 {
            padding: 5px 0;
            background-color: #CD171E;
            font-size: 14px;
            line-height: 1.8;
            color: #fff;
        }

        .copyrights2 a{
            display: inline-block;
            margin: 0 3px;
            color: #fff;
        }

        .copyrights2 a:hover {
            display: inline-block;
            margin: 0 3px;
            color:#ffffff;
        }

        li{
            color: rgb(255, 255, 255);
        }

        .card{
            text-align: center;
            display: auto;
            align-items: center;
            border-radius: 10px;
            /* padding: 10px; */
            max-width: 700px;
            width: 100%;
            box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.2);
        }

        .icon-large {
            font-size: 75px; /* Ajusta el tamaño según lo que necesites */
        }


    /* Sección del modal para agrandar Flyer */
    .img-container {
    position: relative;
    display: inline-block;
    }

    .zoom-icon {
        position: absolute;
        top: 10px;
        right: 10px;
        background: rgba(0, 0, 0, 0.6);
        color: white;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        opacity: 0;
        transition: opacity 0.3s;
    }

    .img-container:hover .zoom-icon {
        opacity: 1;
    }

    .zoomable-img {
        cursor: pointer;
        transition: transform 0.3s;
    }

    .zoomable-img:hover {
        transform: scale(1.02);
    }

    .fullscreen-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.9);
        z-index: 1000;
        text-align: center;
    }

    .fullscreen-img {
        max-width: 90%;
        max-height: 90%;
        margin-top: 5%;
    }

    .close-btn {
        position: absolute;
        top: 20px;
        right: 30px;
        color: white;
        font-size: 35px;
        cursor: pointer;
    }
    /* Aqui acaba */
    </style>

<!-- Modal -->
<div id="fullscreen-modal" class="fullscreen-modal">
</div>

<!-- JavaScript del modal-->
<script>
    function openFullscreen(element) {
        const imgSrc = element.closest('.img-container').querySelector('.zoomable-img').src;
        const modal = document.getElementById('fullscreen-modal');
        const fullscreenImg = document.getElementById('fullscreen-img');
        
        fullscreenImg.src = imgSrc;
        modal.style.display = "block";
    }

    function closeFullscreen() {
        document.getElementById('fullscreen-modal').style.display = "none";
    }

    // Cerrar al hacer clic fuera de la imagen
    window.onclick = function(event) {
        const modal = document.getElementById('fullscreen-modal');
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>


    <script src="./js/bootstrap.bundle.min.js"></script> <!--Esto se usa para llamar a la carpeta de js de bootstrap--> 
</body>
</html>