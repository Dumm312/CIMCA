<?php
include "Modelo/conexion.php"; // Asegúrate de tener tu conexión aquí
session_start();

// Verificar si llegaron los datos
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['congreso']) && isset($_FILES['archivo'])) {
    $edicion = trim($_POST['congreso']);

    // Validar y procesar el archivo
    $archivo = $_FILES['archivo'];
    $nombreArchivo = basename($archivo['name']);
    $tipo = pathinfo($nombreArchivo, PATHINFO_EXTENSION);

    // Crear carpeta si no existe
    $rutaDestino = "imagenes/Flyers/";
    if (!file_exists($rutaDestino)) {
        mkdir($rutaDestino, 0777, true);
    }

    // Generar nombre único
    $nombreUnico = "flyer_" . $edicion . "." . $tipo;
    $rutaFinal = $rutaDestino . $nombreUnico;

    // Mover archivo
    if (move_uploaded_file($archivo['tmp_name'], $rutaFinal)) {
        // 1. Insertar congreso
        $stmt = $conn->prepare("INSERT INTO congreso (edicion, estatus, flyer) VALUES (?, 1, ?)");
        $stmt->bind_param("ss", $edicion, $rutaFinal);

        if ($stmt->execute()) {
            $id_Congreso = $conn->insert_id;

            // 2. Insertar ejes
            $ejes = [
                ['imagenes/Ejes/Agua.webp',                 'Agua'],
                ['imagenes/Ejes/suelo.png',                 'Suelo'],
                ['imagenes/Ejes/aire.avif',                 'Aire'],
                ['imagenes/Ejes/residuos.jpg',              'Residuos'],
                ['imagenes/Ejes/materialesPeligrosos.avif', 'Materiales Peligrosos'],
                ['imagenes/Ejes/cambioClimatico.jpg',       'Cambio Climático']
            ];

            $id_ejes = [];
            foreach ($ejes as $eje) {
                $stmt = $conn->prepare("INSERT INTO ejes (id_Congreso, logo_Eje, tema) VALUES (?, ?, ?)");
                $stmt->bind_param("iss", $id_Congreso, $eje[0], $eje[1]);
                $stmt->execute();
                $id_ejes[] = $conn->insert_id;
            }

            // 3. Insertar subtemas (asociados a los id_ejes generados)
            $subtemas = [
                [0, ['1.1 Contaminación de agua superficial y subteránea','1.2 Medios de Mitigación','1.3 Tecnologías en el tratamiento','1.4 Educación ambiental','1.5 Variables ambientales en el océano','1.6 Contaminación oceánica']],
                [1, ['2.1 Cambio y contaminación de suelos','2.2 Rehabilitación de suelos contaminados','2.3 Transporte de contaminantes en el suelo','2.4 Educación ambiental']],
                [2, ['3.1 Emisiones atmosféricas','3.2 Medidas de control atmosférico','3.3 Calidad del aire','3.4 Educación ambiental','3.5 Modelación de la atmósfera']],
                [3, ['4.1 Residuos peligrosos','4.2 Residuos de manejo especial','4.3 Residuos sólidos urbanos','4.4 Residuos de aparatos eléctricos y electrónicos','4.5 Valorización de residuos']],
                [4, ['5.1 Manejo seguro para el ambiente y la salud humana','5.2 Riesgos químicos','5.3 Gestión integral','5.4 Educación ambiental','5.5 Cartografía en eventos extraordinarios']],
                [5, ['6.1 Tecnología para la detección de Gases de Efecto Invernadero (GEI)','6.2 Metodologías aplicadas al uso de energías limpias','6.3 Estudios en captura de Gases de Efecto Invernadero (GEI)','6.4 Técnicas para la reducción de emisiones fugitivas de GEI']]
            ];

            foreach ($subtemas as [$ejeIndex, $temas]) {
                $id_Eje = $id_ejes[$ejeIndex];
                foreach ($temas as $subtema) {
                    $stmt = $conn->prepare("INSERT INTO subtema (id_Eje, subtema) VALUES (?, ?)");
                    $stmt->bind_param("is", $id_Eje, $subtema);
                    $stmt->execute();
                }
            }

            // 4. Insertar patrocinadores (puedes ajustar esto si tienes una lista)
            $patrocinadores = [
                ['Alux',            'imagenes/Patrocinadores/carrusel - alux.png'],
                ['Casa Sauza',      'imagenes/Patrocinadores/carrusel - casaSauza.png'],
                ['CenaGas',         'imagenes/Patrocinadores/carrusel - cenaGas.png'],
                ['CMIC',            'imagenes/Patrocinadores/carrusel - cmic.png'],
                ['Historia Cafe',   'imagenes/Patrocinadores/carrusel - historiaCafe.png'],
                ['Radio',           'imagenes/Patrocinadores/carrusel - ingenieriaEnMarcha.png'],
                ['LuchBreak',       'imagenes/Patrocinadores/carrusel - luchBreak.png'],
                ['Mexico Minero',   'imagenes/Patrocinadores/carrusel - mexicoMinero.png'],
                ['Casa Sauza',      'imagenes/Patrocinadores/carrusel - casaSauza.png'],
                ['NOLTE',           'imagenes/Patrocinadores/carrusel - nolte.png'],
                ['Ruta Huasteca',   'imagenes/Patrocinadores/carrusel - rutaHuasteca.png'],
                ['Scotiabank',      'imagenes/Patrocinadores/carrusel - scotiabank.png'],
                ['Talara',          'imagenes/Patrocinadores/carrusel - talara.png'],
                ['Via San Clemente','imagenes/Patrocinadores/carrusel - viaSanClemente.png'],
                ['VirtualPlant',    'imagenes/Patrocinadores/carrusel - virtualPlant.png'],
                ['VirtualPro',      'imagenes/Patrocinadores/carrusel - virtualPro.png'],
                ['Waters',          'imagenes/Patrocinadores/carrusel - waters.png'],
                ['WEER',            'imagenes/Patrocinadores/carrusel - weer.png']
            ];

            foreach ($patrocinadores as [$nombre, $imagen]) {
                $stmt = $conn->prepare("INSERT INTO patrocinador (id_Congreso, nombre_Pat, imagen) VALUES (?, ?, ?)");
                $stmt->bind_param("iss",$id_Congreso, $nombre, $imagen);
                $stmt->execute();
            }

            // 5: Insertar materias en la tabla COMITE
            $materias = [
                ['Agua'],
                ['Suelo'],
                ['Aire'],
                ['Residuos Sólidos y Manejo Especial'],
                ['Materiales y Residuos Peligrosos'],
                ['Riesgo Químico'],
                ['Cambio Climático']
            ];

            $ids_comite = []; // Aquí guardaremos los id_materia generados
            foreach ($materias as $m) {
                $stmt = $conn->prepare("INSERT INTO COMITE (materia, id_Congreso) VALUES (?, ?)");
                $stmt->bind_param("si", $m[0], $id_Congreso);
                $stmt->execute();
                $ids_comite[] = $conn->insert_id; // Guardamos el id_materia autogenerado
                $stmt->close();
            }


            // 6: Insertar miembros del comité
            $miembros = [
                [0, 'Dra. Ana Elisa Silva Martínez',         'Facultad de Ingeniería, Universidad Nacional Autónoma de México (México)'],
                [0, 'Dra. Ma. Elena Rodrigo Clavero',        'Instituto Universitario de Ingeniería del Agua y del Medio Ambiente, Universitat Politècnica de València (España)'],
                [1, 'Dr. Javier Rodrigo Ilarri',             'Instituto Universitario de Ingeniería del Agua y del Medio Ambiente, Universitat Politècnica de València (España)'],
                [1, 'Ing. Esp. Santiago Banda Santamaría',   'Facultad de Ingeniería, Universidad Nacional Autónoma de México (México)'],
                [2, 'Dr. Iván Yassmany Hernández Paniagua',  'Instituto de Ciencias de la Atmósfera y Cambio Climático, Universidad Nacional Autónoma de México (México)'],
                [2, 'Dra. Gema Luz Andraca Ayala',           'Instituto de Ciencias de la Atmósfera y Cambio Climático, Universidad Nacional Autónoma de México (México)'],
                [3, 'Dra. María Neftalí Rojas Valencia',     'Instituto de Ingeniería, Universidad Nacional Autónoma de México (México)'],
                [3, 'MSc. Edith Gabriela Guisbert Lizarazu', 'Facultad de Ingeniería, Universidad Mayor de San Andrés (Bolivia)'],
                [4, 'Dra. Georgina Fernández Villagómez',    'Facultad de Ingeniería, Universidad Nacional Autónoma de México (México)'],
                [4, 'MSc. Javier Mauricio González Díaz',    'Facultad de Ingeniería, Universidad La Salle (Colombia)'],
                [5, 'Dr. Luis Antonio García Villanueva',    'Facultad de Ingeniería, Universidad Nacional Autónoma de México (México)'],
                [5, 'Ing. Daniel Alfonso Reséndiz García',   'Facultad de Ingeniería, Universidad Nacional Autónoma de México (México)'],
                [6, 'MSc. Duván Javier Mesa Fernández',      'Facultad de Ingeniería, Universidad La Salle (Colombia)'],
                [6, 'Dra. Griselda Berenice Hernández Cruz', 'Facultad de Ingeniería, Universidad Nacional Autónoma de México (México)']
            ];

            foreach ($miembros as $m) {
                $id_materia = $ids_comite[$m[0]]; // obtenemos el id_materia correcto usando el índice
                $stmt = $conn->prepare("INSERT INTO MIEM_COMITE (id_Materia, gradoYNombre, facultad, id_Congreso) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("issi", $id_materia, $m[1], $m[2], $id_Congreso);
                $stmt->execute();
                $stmt->close();
            }

            echo '<script>alert("Congreso y registros relacionados creados correctamente.."); window.location.href="index.php";</script>';
        } else {
            echo '<script>alert("Error al registrar el congreso en la base de datos."); window.history.back();</script>';
        }

        $stmt->close();
    } else {
        echo '<script>alert("Error al subir el archivo."); window.history.back();</script>';
    }
} else {
    echo '<script>alert("Datos incompletos."); window.history.back();</script>';
}
?>
