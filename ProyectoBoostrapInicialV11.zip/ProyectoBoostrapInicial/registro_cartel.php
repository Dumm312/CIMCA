<?php
session_start();
include("Modelo/conexion.php");

$correo = $_SESSION['correo'];

// Obtener ID del usuario
$sql = "SELECT id_Usuario, ap_Pat, nombre FROM USUARIO WHERE correo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "Usuario no encontrado.";
    exit;
}

$row = $result->fetch_assoc();
$id_usuario = $row['id_Usuario'];
$nombre = $row['nombre'];
$ap_Pat = $row['ap_Pat'];
$id_congreso = 1;
$archivoRuta = "";

// Subir archivo si se proporcionó
if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === 0) {
    $nombreArchivo = basename($_FILES['archivo']['name']);
    $archivoRuta = "archivos/" . $ap_Pat . "_" . $nombre . ".pdf" ;
    move_uploaded_file($_FILES['archivo']['tmp_name'], $archivoRuta);
}

// Revisar si ya hay registro
$check_sql = "SELECT * FROM EVENTO WHERE id_Usuario = ? AND id_Congreso = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("ii", $id_usuario, $id_congreso);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    // Ya hay registro
    if (!isset($_GET['sobreescribir'])) {
        echo "
        <script>
            if (confirm('Ya estás registrado al evento. ¿Deseas sobrescribir tu registro como CARTEL?')) {
                window.location.href = 'registro_cartel.php?sobreescribir=1';
            } else {
                window.location.href = 'index.php';
            }
        </script>";
        exit;
    }

    // Si el usuario aceptó sobrescribir, actualiza
    $update_sql = "UPDATE EVENTO SET asistente = 0, cartel = 1, ponencia = 0
                   WHERE id_Usuario = ? AND id_Congreso = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ii", $id_usuario, $id_congreso);

    if ($update_stmt->execute()) {
        echo "<script>alert('Registro actualizado exitosamente.'); window.location.href = 'index.php';</script>";
        exit;
    } else {
        echo "Error al actualizar: " . $conn->error;
        exit;
    }

} else {
    // No hay registro previo, insertamos
    $insert_sql = "INSERT INTO EVENTO (id_Usuario, id_Congreso, asistente, cartel, ponencia) 
                   VALUES (?, ?, 0, 1, 0, ?)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("ii", $id_usuario, $id_congreso);

    if ($insert_stmt->execute()) {
        echo "<script>alert('Registro exitoso como CARTEL.'); window.location.href = 'index.php';</script>";
        exit;
    } else {
        echo "Error al registrar: " . $conn->error;
        exit;
    }
}
?>
