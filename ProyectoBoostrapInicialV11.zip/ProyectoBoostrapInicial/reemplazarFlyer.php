<?php
include "Modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['nuevo_flyer'])) {
    $id = $_POST['id_congreso'];
    $archivo = $_FILES['nuevo_flyer'];

    // Validación rápida
    if ($archivo['error'] === 0 && is_uploaded_file($archivo['tmp_name'])) {
        $nombreNuevo = "imagenes/Flyers/flyer_$id." . pathinfo($archivo['name'], PATHINFO_EXTENSION);
        move_uploaded_file($archivo['tmp_name'], $nombreNuevo);

        // Actualizar la base de datos
        $stmt = $conn->prepare("UPDATE congreso SET flyer = ? WHERE id_Congreso = ?");
        $stmt->bind_param("si", $nombreNuevo, $id);
        $stmt->execute();

        header("Location: index.php?id_congreso=" . $id);
        exit();
    } else {
        echo "Error al subir el archivo.";
    }
}
?>
