<?php
include "Modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id_Congreso'] ?? null;
    $estatus = $_POST['estatus'] ?? null;

    if ($id !== null && ($estatus === "0" || $estatus === "1")) {
        $stmt = $conn->prepare("UPDATE congreso SET estatus = ? WHERE id_Congreso = ?");
        $stmt->bind_param("ii", $estatus, $id);
        if ($stmt->execute()) {
            echo "Actualización exitosa";
        } else {
            echo "Error al actualizar";
        }
        $stmt->close();
    } else {
        echo "Datos inválidos";
    }
    $conn->close();
} else {
    echo "Método no permitido";
}
