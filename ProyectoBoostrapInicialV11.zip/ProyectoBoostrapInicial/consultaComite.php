<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$host = "localhost";
$user = "root";  // Cambia esto si usas otro usuario
$password = "";  // Cambia esto si tienes una contraseña
$dbname = "cimca";

$conn = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die(json_encode(["error" => "Error en la conexión: " . $conn->connect_error]));
}

// Obtener los comites
$sql = "SELECT * FROM comite";
$result = $conn->query($sql);

$comite = [];
while ($row = $result->fetch_assoc()) {
    // Añadir la ruta de la imagen correctamente
    //$row['imagen'] = "imagenes/" . $row['imagen'];
    $comite[] = $row;
}

echo json_encode($comite);

$conn->close();
?>
