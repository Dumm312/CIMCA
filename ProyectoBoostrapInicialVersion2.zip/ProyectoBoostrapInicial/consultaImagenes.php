<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$host = "localhost";
$user = "root";  // Cambia esto si usas otro usuario
$password = "";  // Cambia esto si tienes una contraseña
$dbname = "cimca";
$conn = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die(json_encode(["error" => "Error en la conexión: " . $conn->connect_error]));
}

// Obtener las imagenes
$sql = "SELECT * FROM imagenes";
$result = $conn->query($sql);

$imagenes = [];
while ($row = $result->fetch_assoc()) {
    // Añadir la ruta de la imagen correctamente
    //$row['imagen'] = "Carrusel-Imagenes/" . $row['imagen'];
    $imagenes[] = $row;
}

echo json_encode($imagenes);

$conn->close();
?>
