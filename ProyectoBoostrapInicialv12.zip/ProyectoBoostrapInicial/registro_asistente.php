<?php
session_start();

include("Modelo/conexion.php");

$correo = $_SESSION['correo'];

// Obtener el id_Usuario a partir del correo
$sql = "SELECT id_Usuario FROM USUARIO WHERE correo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $id_usuario = $row['id_Usuario'];

    $id_congreso = 1; // Ajustar dinámicamente si se requiere

    // Verificar si ya existe registro
    $check_sql = "SELECT * FROM EVENTO WHERE id_Usuario = ? AND id_Congreso = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $id_usuario, $id_congreso);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    // Si ya hay un registro y no se ha solicitado sobreescribir
    if ($check_result->num_rows > 0 && !isset($_GET['sobreescribir'])) {
        echo "
        <script>
            if (confirm('Ya estás registrado al evento. ¿Deseas sobrescribir tu registro?')) {
                window.location.href = 'registro_asistente.php?sobreescribir=1';
            } else {
                window.location.href = 'index.php';
            }
        </script>";
        exit;
    }

    // Si se solicitó sobreescribir, eliminar registro previo
    if (isset($_GET['sobreescribir']) && $_GET['sobreescribir'] == 1) {
        $delete_sql = "DELETE FROM EVENTO WHERE id_Usuario = ? AND id_Congreso = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("ii", $id_usuario, $id_congreso);
        $delete_stmt->execute();
    }

    // Insertar nuevo registro
    $sql_insert = "INSERT INTO EVENTO (id_Usuario, id_Congreso, asistente, cartel, ponencia) 
                   VALUES (?, ?, 1, 0, 0)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("ii", $id_usuario, $id_congreso);

    if ($stmt_insert->execute()) {
        echo "<script>alert('Registro como asistente exitoso'); window.location.href = 'index.php';</script>";
        exit;
    } else {
        echo "Error al registrar: " . $conn->error;
    }
} else {
    echo "Usuario no encontrado.";
}
?>
