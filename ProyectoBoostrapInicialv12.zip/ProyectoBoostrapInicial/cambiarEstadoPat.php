<?php
session_start();
include "Modelo/conexion.php";

// 1. Recibir el ID manteniendo tus nombres exactos
$id_Patrocinador = $_POST['id_Patrocinador'] ?? null;

// 2. Validación básica sin mensajes de error
if(!$id_Patrocinador) {
    header("Location: indexAdmin.php");
    exit();
}

try {
    // 3. Consulta para obtener estado actual (manteniendo tus nombres)
    $sql = "SELECT estado FROM patrocinador WHERE id_Patrocinador = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_Patrocinador);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // 4. Si no hay resultados, redirigir sin mensaje
    if($result->num_rows === 0) {
        header("Location: indexAdmin.php");
        exit();
    }
    
    $row = $result->fetch_assoc();
    $estado_actual = $row['estado'];
    
    // 5. Lógica para alternar estado (como en tu versión)
    $nuevo_estado = ($estado_actual == 1 || $estado_actual == '1') ? 0 : 1;
    
    // 6. Actualización en la BD (con tus nombres de campos)
    $sql_update = "UPDATE patrocinador SET estado = ? WHERE id_Patrocinador = ?";
    $stmt = $conn->prepare($sql_update);
    $stmt->bind_param("ii", $nuevo_estado, $id_Patrocinador);
    
    $stmt->execute();
    
    // 7. Redirección con mensaje de éxito
    $_SESSION['mensaje_exito'] = "Estado actualizado correctamente";
    header("Location: indexAdmin.php");
    exit();
    
} catch (Exception $e) {
    // 8. Redirección silenciosa en caso de error
    header("Location: indexAdmin.php");
    exit();
}
?>