<?php
session_start();
include "Modelo/conexion.php";

// Debug: Verifica qué hay en la sesión
// error_log("Datos de sesión: " . print_r($_SESSION, true));

// // Verificación modificada
// if (!isset($_SESSION['id_Usuario'])) {
//     error_log("Redirección a login - No hay usuario en sesión");
//     header("Location: login.php");
//     exit();
// }

// if ($_SESSION['tipo_usuario'] != 'AL') {
//     error_log("Redirección a login - Usuario no es admin. Tipo: " . $_SESSION['tipoUsuario']);
//     $_SESSION['error'] = "No tienes permisos de administrador";
//     header("Location: login.php");
//     exit();
// }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_usuario = $_POST['id_Usuario'] ?? null;
    $nuevo_estado = trim($_POST['nuevo_estado'] ?? '');

    error_log("Intentando actualizar estado. Usuario ID: $id_usuario, Nuevo estado: $nuevo_estado");

    if ($id_usuario && !empty($nuevo_estado)) {
        try {
            $stmt = $conn->prepare("UPDATE evento SET estatusA = ? WHERE id_Usuario = ?");
            $stmt->bind_param("si", $nuevo_estado, $id_usuario);
            
            if ($stmt->execute()) {
                $_SESSION['mensaje'] = "Estado actualizado correctamente";
                error_log("Actualización exitosa para usuario $id_usuario");
            } else {
                $_SESSION['error'] = "Error al actualizar: " . $stmt->error;
                error_log("Error en consulta: " . $stmt->error);
            }
        } catch (Exception $e) {
            $_SESSION['error'] = "Error de base de datos: " . $e->getMessage();
            error_log("Excepción: " . $e->getMessage());
        }
    } else {
        $_SESSION['error'] = "Datos incompletos para la actualización";
        error_log("Datos incompletos recibidos");
    }
    
    // Redirigir a la página anterior con parámetros debug
    $referer = $_SERVER['HTTP_REFERER'] ?? 'EditMiPerfil.php';
    error_log("Redirigiendo a: $referer");
    header("Location: $referer");
    exit();
}

header("Location: EditMiPerfil.php");
exit();
?>