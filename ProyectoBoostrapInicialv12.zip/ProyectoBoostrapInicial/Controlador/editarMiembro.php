<?php
include "../Modelo/conexion.php";
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $cargo = $_POST['cargo'];
    $id_comite = $_POST['id_Comite'];

    $foto = $_FILES['foto']['name'];
    $tmp = $_FILES['foto']['tmp_name'];

    if ($foto) {
        $ruta = "imagenes/Miembros_Comites/" . $foto;
        move_uploaded_file($tmp, "../" . $ruta);
        $sql = "UPDATE miem_comite 
                SET nombre='$nombre', cargo='$cargo', foto='$ruta', id_Comite='$id_comite'
                WHERE id_miembro=$id";
    } else {
        $sql = "UPDATE miem_comite 
                SET nombre='$nombre', cargo='$cargo', id_Comite='$id_comite'
                WHERE id_miembro=$id";
    }

    mysqli_query($conn, $sql);
    header("Location: ../ComiteEvaluadorAdmin.php");
}

$sql = "SELECT * FROM miem_comite WHERE id_miembro = $id";
$res = mysqli_query($conn, $sql);
$miembro = mysqli_fetch_assoc($res);
?>

<!-- Formulario (puedes colocarlo en tu archivo HTML/PHP según el diseño) -->
<form action="" method="POST" enctype="multipart/form-data">
    <input type="text" name="nombre" value="<?= $miembro['nombre'] ?>" class="form-control mb-2" required>
    <input type="text" name="cargo" value="<?= $miembro['cargo'] ?>" class="form-control mb-2" required>
    <input type="number" name="id_Comite" value="<?= $miembro['id_Comite'] ?>" class="form-control mb-2" required>
    <input type="file" name="foto" class="form-control mb-2">
    <button type="submit" class="btn btn-primary">Actualizar</button>
</form>
