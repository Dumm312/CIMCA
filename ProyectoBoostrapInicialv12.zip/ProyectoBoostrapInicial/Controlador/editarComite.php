<?php
include "../Modelo/conexion.php";
$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $materia = $_POST['materia'];
    $id_Congreso = $_POST['id_Congreso'];
    
    $sql = "UPDATE comite SET materia='$materia', id_Congreso='$id_Congreso' WHERE id_Materia=$id";
    mysqli_query($conn, $sql);
    header("Location: ../ComiteEvaluadorAdmin.php");
}

$sql = "SELECT * FROM comite WHERE id_Materia = $id";
$res = mysqli_query($conn, $sql);
$comite = mysqli_fetch_assoc($res);
?>

<form action="" method="POST">
    <input type="text" name="materia" value="<?= $comite['materia'] ?>" class="form-control mb-2" required>

    <!-- id_Congreso fijo en 1-->
    <input type="hidden" name="id_Congreso" value="1">

    <button class="btn btn-primary" type="submit">Actualizar</button>
</form>

