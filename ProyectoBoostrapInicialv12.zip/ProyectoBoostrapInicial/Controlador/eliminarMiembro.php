<?php
include "../Modelo/conexion.php";
$id = $_GET['id'];

$sql = "DELETE FROM miem_comite WHERE id_Persona = $id";
mysqli_query($conn, $sql);

header("Location: ../ComiteEvaluadorAdmin.php");
