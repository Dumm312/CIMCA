<?php
include "../Modelo/conexion.php";

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subtema = $_POST['subtema'];
    $id_Eje = $_POST['id_Eje'];
    mysqli_query($conn, "UPDATE subtema SET subtema='$subtema', id_Eje=$id_Eje WHERE id_Subtema=$id");
    header("Location: ../ejesTematicosAdmin.php"); //Redirección a la página que deseemos una vez efectuadoe l cambio
    exit;
}

$res = mysqli_query($conn, "SELECT * FROM subtema WHERE id_Subtema = $id");
$subtemaData = mysqli_fetch_assoc($res);

// Obtener ejes para selector
$ejes = mysqli_query($conn, "SELECT * FROM ejes");
?>

<div class="container mt-5">
    <h4>Editar Subtema</h4>
    <form method="POST">
        <input type="text" name="subtema" class="form-control mb-2" value="<?= $subtemaData['subtema'] ?>" required>

        <select name="id_Eje" class="form-control mb-2" required>
            <?php while ($eje = mysqli_fetch_assoc($ejes)) {
                $selected = ($eje['id_Eje'] == $subtemaData['id_Eje']) ? 'selected' : '';
                echo "<option value='{$eje['id_Eje']}' $selected>{$eje['tema']}</option>";
            } ?>
        </select>

        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
</div>
