<?php
include "../Modelo/conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tema = $_POST['tema'];
    $id_Congreso = $_POST['id_Congreso'];

    // Subir imagen
    $nombreLogo = $_FILES['logo_Eje']['name'];
    $tmp = $_FILES['logo_Eje']['tmp_name'];
    $rutaRelativa = "./imagenes/Ejes/" . $nombreLogo;

    move_uploaded_file($tmp, $rutaRelativa);

    // Guardar en BD la ruta completa relativa
    $sql = "INSERT INTO ejes (tema, id_Congreso, logo_Eje) VALUES ('$tema', $id_Congreso, '$rutaRelativa')";
    if (mysqli_query($conn, $sql)) {
        echo mysqli_insert_id($conn); //
    } else {
        echo "error";
    }
}
?>
