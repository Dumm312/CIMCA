<?php
include "../Modelo/conexion.php";

$id = $_GET['id'];

// Primero obtenemos los datos del eje si es GET
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $sql = "SELECT * FROM ejes WHERE id_Eje = $id";
    $res = mysqli_query($conn, $sql);
    $eje = mysqli_fetch_assoc($res);
}

// Si se está enviando el formulario por POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tema = $_POST['tema'];

    // Verificamos si se cargó una nueva imagen
    if (isset($_FILES['logo_Eje']) && $_FILES['logo_Eje']['error'] == 0) {
        $logo = $_FILES['logo_Eje']['name'];
        $tmp = $_FILES['logo_Eje']['tmp_name'];
        $ruta = "./imagenes/Ejes/" . $logo;

        move_uploaded_file($tmp, $ruta);

        $sql = "UPDATE ejes SET tema='$tema', logo_Eje='$ruta' WHERE id_Eje=$id";
    } else {
        $sql = "UPDATE ejes SET tema='$tema' WHERE id_Eje=$id";
    }

    mysqli_query($conn, $sql);
    header("Location: ../ejesTematicosAdmin.php");
    exit();
}
?>

<!-- Formulario HTML -->
<form action="" method="POST" enctype="multipart/form-data">
    <input type="text" name="tema" value="<?= isset($eje['tema']) ? $eje['tema'] : '' ?>" required>
    <input type="file" name="logo_Eje">
    <button type="submit">Actualizar</button>
</form>
