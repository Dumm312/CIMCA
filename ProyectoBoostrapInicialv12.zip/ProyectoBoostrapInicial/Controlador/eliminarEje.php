<?php
include "../Modelo/conexion.php";
$id = $_GET['id'];

$sql = "DELETE FROM ejes WHERE id_Eje = $id";
mysqli_query($conn, $sql);

header("Location: ../ejesTematicosAdmin.php");
?>
