<?php
include "../Modelo/conexion.php";

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM subtema WHERE id_Subtema = $id");

header("Location: ../ejesTematicosAdmin.php");
