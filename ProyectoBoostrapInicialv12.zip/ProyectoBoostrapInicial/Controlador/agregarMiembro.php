<?php
include "../Modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['gradoYNombre'];
    $facultad = $_POST['facultad'];
    $id_Materia = $_POST['id_Materia'];

    $foto = $_FILES['foto']['name'];
    $tmp = $_FILES['foto']['tmp_name'];

    if (!empty($foto)) {
        // Ruta física en el servidor (donde se guardará)
        $rutaServidor = "../imagenes/Miembros_Comites/" . $foto;

        // Ruta relativa que se guarda en la base de datos
        $rutaBD = "imagenes/Miembros_Comites/" . $foto;

        // Verifica si se subió correctamente
        if (move_uploaded_file($tmp, $rutaServidor)) {
            $sql = "INSERT INTO miem_comite (gradoYNombre, facultad, id_Materia, foto)
                    VALUES ('$nombre', '$facultad', $id_Materia, '$rutaBD')";
        } else {
            echo "Error al mover la imagen. Verifica permisos en la carpeta destino.";
            exit;
        }
    } else {
        // Si no se subió imagen, insertamos NULL o campo vacío
        $sql = "INSERT INTO miem_comite (gradoYNombre, facultad, id_Materia)
                VALUES ('$nombre', '$facultad', $id_Materia)";
    }

    if (mysqli_query($conn, $sql)) {
        header("Location: ../ComiteEvaluadorAdmin.php");
        exit;
    } else {
        echo "Error al insertar en la BD: " . mysqli_error($conn);
    }
}
?>
