<?php
include "../Modelo/conexion.php";

$subtema = trim($_POST['subtema']);
$id_Eje = $_POST['id_Eje'];

if (!empty($subtema) && $id_Eje) {
    mysqli_query($conn, "INSERT INTO subtema (subtema, id_Eje) VALUES ('$subtema', $id_Eje)");
}
header("Location: ../ejesTematicosAdmin.php");
