<?php
include "../Modelo/conexion.php";
$id = $_GET['id'];

$sql = "DELETE FROM comite WHERE id_Materia = $id";
mysqli_query($conn, $sql);

header("Location: ../ComiteEvaluadorAdmin.php");
