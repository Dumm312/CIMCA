<?php
include "../Modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $materia = $_POST['materia'];

    // Insertar directamente con id_Congreso fijo en 1
    $query = "INSERT INTO comite (materia, id_Congreso) VALUES ('$materia', 1)";
    mysqli_query($conn, $query);

    header("Location: ../ComiteEvaluadorAdmin.php");
}
?>
