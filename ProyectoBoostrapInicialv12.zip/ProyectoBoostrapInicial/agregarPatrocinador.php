<?php
session_start();
include "Modelo/conexion.php";

// Verificar permisos de administrador
// if (!isset($_SESSION['usuario']) || $_SESSION['tipo_usuario'] != 'admin') {
//     $_SESSION['error'] = "Acceso denegado";
//     header("Location: index2.php");
//     exit();
// }

// Obtener datos del formulario
$nombre_Pat = $_POST['nombre_Pat'] ?? '';
$estado = $_POST['estado'] ?? '1';
$id_Congreso = $_POST['id_Congreso'] ?? 1;

// Procesar la imagen
$directorio = "archivos/patrocinadores/";
if (!file_exists($directorio)) {
    mkdir($directorio, 0777, true);
}

$nombre_archivo = uniqid() . '_' . basename($_FILES["imagen"]["name"]);
$ruta_archivo = $directorio . $nombre_archivo;

// Validar y mover el archivo
if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $ruta_archivo)) {
    try {
        // Insertar en la base de datos
        $sql = "INSERT INTO patrocinador (nombre_Pat, imagen, estado, id_Congreso) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $nombre_Pat, $ruta_archivo, $estado, $id_Congreso);
        
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "Patrocinador añadido correctamente";
        } else {
            // Eliminar la imagen si falla la inserción
            unlink($ruta_archivo);
            throw new Exception("Error al guardar en la base de datos: " . $stmt->error);
        }
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
} else {
    $_SESSION['error'] = "Error al subir la imagen";
}

// Redireccionar
header("Location: indexAdmin.php");
exit();
?>