<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$host = "localhost";
$user = "root";  // Cambia esto si usas otro usuario
$password = "";  // Cambia esto si tienes una contraseña
$dbname = "cimca";

$conn = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die(json_encode(["error" => "Error en la conexión: " . $conn->connect_error]));
}

// Obtener los Ejes
$sql = "SELECT * FROM ejes";
$result = $conn->query($sql);

$ejes = [];
while ($row = $result->fetch_assoc()) {
    // Añadir la ruta de la imagen correctamente
    //$row['imagen'] = "imagenes/" . $row['imagen'];
    $ejes[] = $row;
}

echo json_encode($ejes);

$conn->close();
?>
