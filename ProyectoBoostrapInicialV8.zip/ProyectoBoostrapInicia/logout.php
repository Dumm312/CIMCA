<?php
session_start();
session_destroy(); // Destruye la sesión actual
header("Location: IniciarSesion.php"); // Redirige al login
exit;
?>
