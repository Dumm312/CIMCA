<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regístrate</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="formatoRegistro.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<header style="background-color: #E3E3E3;">
    <div id="Flyer" class="container">
        <div class="d-flex flex-wrap justify-content-center gap">
            <div class="d-flex align-items-center" style="gap: 1rem;">
                <a href="https://www.unam.mx"><img src="./imagenes/Logo Unam.png" class="card-img-top" alt="Logo Unam" style="width: 15rem; margin-right: 15rem;"></a>
                <img src="./imagenes/logo.png" class="card-img-top" alt="Logo CIMCA" style="width: 6.5rem;">
                <a href="https://www.ingenieria.unam.mx"><img src="./imagenes/Logo FI.png" class="card-img-top" alt="Logo FI" style="width: 22rem; margin-left: 15rem;"></a>
            </div>
        </div>
    </div>
</header>

<body>
    <nav class="navbar navbar-expand-lg sticky-top" style="border-top: 3px solid red; border-bottom: 3px solid red; background-color: white; z-index: 1000;">
        <div class="container-fluid">
            <!-- Botón toggler para móviles -->
            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Contenido colapsable -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav w-100 justify-content-center gap-lg-3">
                    <a class="nav-link" href="index.php">Bienvenido</a>
                    <a class="nav-link" href="objetivos.html">Objetivos</a>
                    <a class="nav-link" href="ejesTematicos.php">Ejes Temáticos</a>
                    <a class="nav-link" href="ComiteEvaluador.php">Comité Evaluador</a>
                    <a class="nav-link" href="IniciarSesion.html">Iniciar Sesión</a>
                    
                    <!-- Esto a continuación solo deberá aparecer cuando se tenga una sesión activa -->
                    <a class="nav-link" href="miperfil.html">Mi perfil</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="text-center">
        <img id="ip_logo" src="./imagenes/logoCIMCA.jpg" style="max-height: 150px; width: 50%;">
    </div>

    <p>¿Ya tienes una cuenta? <a href="IniciarSesion.html"><button>Iniciar sesión</button></a></p>

    <h1 id="TituloRegistro">Regístrate </h1>

    <?php
    $conexion = new mysqli("localhost", "root", "", "cimca");
    if ($conexion->connect_error) {
        die("Conexión fallida: " . $conexion->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $numCuentaRFC = $_POST['numCuentaRFC'];
        $tipoUsuario = $_POST['tipoUsuario'];
        $nombre = $_POST['nombre'];
        $ap_Pat = $_POST['ap_Pat'];
        $ap_Mat = $_POST['ap_Mat'];
        $universidad = $_POST['universidad'];
        $direccion = $_POST['direccion'];
        $telefono = $_POST['telefono'];
        $correo = $_POST['correo'];
        $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
        $grado = isset($_POST['grado']) ? $_POST['grado'] : null;
        $puestoCargo = isset($_POST['puestoCargo']) ? $_POST['puestoCargo'] : null;
        $empresa = isset($_POST['empresa']) ? $_POST['empresa'] : null;
        $areaEspecialidad = isset($_POST['areaEspecialidad']) ? $_POST['areaEspecialidad'] : null;


        $stmt = $conexion->prepare("INSERT INTO usuario 
        (numCuentaRFC, tipoUsuario, nombre, ap_Pat, ap_Mat, universidad, direccion, telefono, correo, contrasena, grado, puestoCargo, empresa, areaEspecialidad)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->bind_param("ssssssssssssss", $numCuentaRFC, $tipoUsuario, $nombre, $ap_Pat, $ap_Mat, $universidad, $direccion, $telefono, $correo, $contrasena, $grado, $puestoCargo, $empresa, $areaEspecialidad);

        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Registro exitoso.</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }

        $stmt->close();
        $conexion->close();
    }
    ?>

    <div class="container">
        <form method="POST">
            <div class="mb-3">
                <label>No. Cuenta / RFC:</label>
                <input type="text" name="numCuentaRFC" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Tipo de usuario:</label>
                <select name="tipoUsuario" id="tipoUsuario" class="form-select" required onchange="toggleCampos()">
                    <option value="">Seleccione</option>
                    <option value="AL">alumno</option>
                    <option value="ID">Investigador/Docente</option>
                    <option value="EI">Empresa/Independiente</option>
                </select>
            </div>

            <div class="mb-3">
                <label>Nombre:</label>
                <input type="text" name="nombre" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Apellido Paterno:</label>
                <input type="text" name="ap_Pat" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Apellido Materno:</label>
                <input type="text" name="ap_Mat" class="form-control">
            </div>

            <div class="mb-3">
                <label>Universidad:</label>
                <input type="text" name="universidad" class="form-control">
            </div>

            <div class="mb-3">
                <label>Dirección:</label>
                <input type="text" name="direccion" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Teléfono:</label>
                <input type="text" name="telefono" maxlength="15" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Correo:</label>
                <input type="email" name="correo" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Contraseña:</label>
                <input type="password" name="contrasena" class="form-control" required>
            </div>

            <div id="camposProfesional">
                <div id= "campo-grado" class="mb-3">
                    <label>Grado académico:</label>
                    <input type="text" name="grado" id="grado" class="form-control">
                </div>

                <div id= "campo-puesto" class="mb-3">
                    <label>Puesto o cargo:</label>
                    <input type="text" name="puestoCargo" id="puestoCargo" class="form-control">
                </div>

                <div id= "campo-empresa" class="mb-3">
                    <label>Empresa:</label>
                    <input type="text" name="empresa" id="empresa" class="form-control">
                </div>

                <div id= "campo-area" class="mb-3">
                    <label>Área de especialidad:</label>
                    <input type="text" name="areaEspecialidad" id="areaEspecialidad" class="form-control">
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Registrarse</button>
        </form>
    </div>

    <script>
    function toggleCampos() {
        const tipo = document.getElementById('tipoUsuario').value;

        const grado = document.getElementById('campo-grado');
        const puesto = document.getElementById('campo-puesto');
        const empresa = document.getElementById('campo-empresa');
        const area = document.getElementById('campo-area');

        if (tipo === 'ID') {
            grado.style.display = 'block';
            puesto.style.display = 'block';
            empresa.style.display = 'none';
            area.style.display = 'none';
        } else if (tipo === 'EI') {
            grado.style.display = 'block';
            puesto.style.display = 'block';
            empresa.style.display = 'block';
            area.style.display = 'block';
        } else {
            grado.style.display = 'none';
            puesto.style.display = 'none';
            empresa.style.display = 'none';
            area.style.display = 'none';
        }
    }

    window.onload = toggleCampos;
    </script>


    <script src="./js/bootstrap.bundle.min.js"></script>
</body>
</html>
