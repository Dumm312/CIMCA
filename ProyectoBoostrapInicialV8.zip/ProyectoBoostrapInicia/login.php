<?php
session_start();
include "Modelo/conexion.php"; // Asegúrate de que esta línea incluya correctamente la conexión

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contraseña'];

    // Consulta preparada para evitar inyección SQL
    $stmt = $conn->prepare("SELECT id_Usuario, correo, contrasena FROM usuario WHERE correo = ? LIMIT 1");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();

        // Verificar la contraseña hasheada
        if (password_verify($contrasena, $usuario['contrasena'])) {
            // Login exitoso
            $_SESSION['usuario_id'] = $usuario['id_Usuario'];
            $_SESSION['correo'] = $usuario['correo'];
            header("Location: miperfil.php"); // o la página principal del usuario
            exit();
        } else {
            // echo "Contraseña incorrecta.";
            echo '<script>alert("Datos incorrectos."); window.location.href="http://localhost/ProyectoBoostrapInicia/IniciarSesion.php";</script>';
        }
    } else {
        // echo "No se encontró una cuenta con ese correo.";
        // echo '<script>window.location.href="https://www.registro.php";</script>';
        echo '<script>alert("No se encontró una cuenta con ese correo."); window.location.href="http://localhost/ProyectoBoostrapInicia/registro.php";</script>';

    }

    $stmt->close();
    $conn->close();
}
?>
